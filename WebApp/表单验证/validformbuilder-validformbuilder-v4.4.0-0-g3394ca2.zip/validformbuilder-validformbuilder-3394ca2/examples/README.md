# Examples

This directory contains a list of 'copy-paste'-able example snippets.
It is just a small show case of the many powerfull features ValidForm Builder contains.

Please feel free to add your own example snippets to this folder if you think something is missing.
